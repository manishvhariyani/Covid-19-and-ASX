-- Looking for Relevant Data
SELECT Location, date, total_cases, new_cases, total_deaths, population
From PortfolioProject..CovidDeaths
order by 1,2


--Calculating Total Cases vs Total Deaths

SELECT Location, date, total_cases, total_deaths, (total_deaths/total_cases)*100 as DeathPercentage
From PortfolioProject..CovidDeaths
Where location like 'Australia'
order by 1,2


--Calculating Total Cases vs polulation (percentage of population got covid)

SELECT Location, date, Population, total_cases, (total_cases/population)*100 as PercentPopulationInfected
From PortfolioProject..CovidDeaths
Where location like 'Australia'
order by 1,2


-- Looking at Countries with Highest Infection Rate as compared to Total Population

SELECT Location, Population, MAX(total_cases) as HighestInfectionCount, MAX((total_cases/population))*100 as PercentPopulationInfected
From PortfolioProject..CovidDeaths
--Where location like 'Australia'
Group by Location,Population
order by PercentPopulationInfected desc


SELECT Location, Population, date, MAX(total_cases) as HighestInfectionCount, MAX((total_cases/population))*100 as PercentPopulationInfected
From PortfolioProject..CovidDeaths
--Where location like 'Australia'
Group by Location,Population, date
order by PercentPopulationInfected desc


-- Looking at Infections Count in Australia

SELECT Location, Population, MAX(total_cases) as HighestInfectionCount, MAX((total_cases/population))*100 as PercentPopulationInfected
From PortfolioProject..CovidDeaths
Where location like 'Australia'
Group by Location,Population
order by PercentPopulationInfected desc


SELECT Location, Population, date, MAX(total_cases) as HighestInfectionCount, MAX((total_cases/population))*100 as PercentPopulationInfected
From PortfolioProject..CovidDeaths
Where location like 'Australia'
Group by Location,Population, date
order by PercentPopulationInfected desc


--Looking at Countries with Highest Death Counts per Total Population
SELECT Location, MAX(cast(total_deaths as int)) as TotalDeathCount
From PortfolioProject..CovidDeaths
--Where location like 'Australia'
Where continent is null
Group by Location
order by TotalDeathCount desc

--Looking at Continents with Highest Death Counts per Total Population
SELECT continent, MAX(cast(total_deaths as int)) as TotalDeathCount
From PortfolioProject..CovidDeaths
--Where location like 'Australia'
Where continent is not null
Group by continent
order by TotalDeathCount desc


--Global Numbers

SELECT SUM(new_cases) as total_cases, SUM(cast(new_deaths as int)) as total_deaths, SUM(CAST(new_deaths as int))/SUM(new_cases)*100 as DeathPercentage
From PortfolioProject..CovidDeaths
--Where location like 'Australia' and continent is not null
where continent is not null
order by 1,2

-- Australian Numbers

SELECT SUM(new_cases) as total_cases, SUM(cast(new_deaths as int)) as total_deaths, SUM(CAST(new_deaths as int))/SUM(new_cases)*100 as DeathPercentage
From PortfolioProject..CovidDeaths
Where location like 'Australia' and continent is not null
--where continent is not null
order by 1,2


-- Looking at Population vs Deaths and Vaccinations
Select dea.continent, dea.location, dea.date, dea.population,
vac.new_vaccinations, SUM(CONVERT(int, vac.new_vaccinations)) OVER (Partition by dea.location order by dea.location, dea.date) as RollingTotalPeopleVaccinated,
dea.new_deaths, SUM(CONVERT(int, dea.new_deaths)) OVER (Partition by dea.location order by dea.location, dea.date) as RollingTotalDeaths
From PortfolioProject..CovidDeaths dea
Join PortfolioProject..CovidVaccinations vac
	on dea.location = vac.location
	and dea.date = vac.date
Where dea.continent is not null and dea.location like 'Australia'
order by 2,3

-- Use CTE

With VacPop (Continent, Location, Date, Population, New_Vaccinations, RollingTotalPeopleVaccinated)
as
(
Select dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations, SUM(CONVERT(int, vac.new_vaccinations)) OVER (Partition by dea.location order by dea.location, dea.date) as RollingTotalPeopleVaccinated
From PortfolioProject..CovidDeaths dea
Join PortfolioProject..CovidVaccinations vac
	on dea.location = vac.location
	and dea.date = vac.date
Where dea.continent is not null
--order by 2,3
)
Select *, (RollingTotalPeopleVaccinated/Population)*100 as VaccinatedPopulation
From VacPop


-- Use Temp TABLE

DROP Table if exists  #VaccinatedPopulationPercent
Create Table #VaccinatedPopulationPercent
(
Continent nvarchar(255),
Location nvarchar(255),
Date datetime,
Population numeric,
New_Vaccinations numeric,
RollingTotalPeopleVaccinated numeric
)

Insert into  #VaccinatedPopulationPercent
Select dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations, SUM(CONVERT(int, vac.new_vaccinations)) OVER (Partition by dea.location order by dea.location, dea.date) as RollingTotalPeopleVaccinated
From PortfolioProject..CovidDeaths dea
Join PortfolioProject..CovidVaccinations vac
	on dea.location = vac.location
	and dea.date = vac.date
Where dea.continent is not null


Select *, (RollingTotalPeopleVaccinated/Population)*100 as VaccinatedPopulation
From #VaccinatedPopulationPercent



-- Creating Views which can be used for Visualizations

USE PortfolioProject
GO
Create View VaccinatedPopulationPct as
Select dea.continent, dea.location, dea.date, dea.population, vac.new_vaccinations, SUM(CONVERT(int, vac.new_vaccinations)) OVER (Partition by dea.location order by dea.location, dea.date) as RollingTotalPeopleVaccinated
From PortfolioProject..CovidDeaths dea
Join PortfolioProject..CovidVaccinations vac
	on dea.location = vac.location
	and dea.date = vac.date
Where dea.continent is not null


Select * from [dbo].[VaccinatedPopulationPct]


USE PortfolioProject
GO
Create View PopulationDeathVaccination as
Select dea.continent, dea.location, dea.date, dea.population,
vac.new_vaccinations, SUM(CONVERT(int, vac.new_vaccinations)) OVER (Partition by dea.location order by dea.location, dea.date) as RollingTotalPeopleVaccinated,
dea.new_deaths, SUM(CONVERT(int, dea.new_deaths)) OVER (Partition by dea.location order by dea.location, dea.date) as RollingTotalDeaths
From PortfolioProject..CovidDeaths dea
Join PortfolioProject..CovidVaccinations vac
	on dea.location = vac.location
	and dea.date = vac.date
Where dea.continent is not null and dea.location like 'Australia'


Select * from [dbo].PopulationDeathVaccination


--Altering XJO Table

ALTER TABLE PortfolioProject..xjo
ALTER COLUMN date DATETIME

Select * from xjo

-- Looking at effects of Deaths, Infections and Vaccinations in Australia on Stoc Market

Select *
From PortfolioProject..CovidDeaths dea
Join PortfolioProject..xjo xjo
	on dea.date = xjo.date
Where dea.location like 'Australia'


Select *
From PortfolioProject..VaccinatedPopulationPct vpp
Join PortfolioProject..xjo xjo
	on vpp.date = xjo.date
Where vpp.location like 'Australia'

Select *
From PortfolioProject..PopulationDeathVaccination pdv
Join PortfolioProject..xjo xjo
	on pdv.date = xjo.date
Where pdv.location like 'Australia'
